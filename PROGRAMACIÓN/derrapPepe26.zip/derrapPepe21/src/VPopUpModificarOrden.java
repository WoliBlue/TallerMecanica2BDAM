import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VPopUpModificarOrden extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField txtReferencia;
    private JComboBox<String> cmbEstado;
    private JTextField txtProceso;
    private JTextField txtDescripcion;
    private JTextField txtFechaSalida;
    private ConexionBD conexion;
    private String referencia;

    public VPopUpModificarOrden(ConexionBD conexion, String referencia) {
        this.conexion = conexion;
        this.referencia = referencia;
        initialize();
    }

    private void initialize() {
        setTitle("DERRAP - Modificar Orden");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 400);
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(243, 141, 52));
        setLayout(null);

        // Labels
        JLabel lblReferencia = new JLabel("Referencia:");
        lblReferencia.setBounds(50, 30, 120, 25);
        add(lblReferencia);

        JLabel lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(50, 70, 120, 25);
        add(lblEstado);

        JLabel lblProceso = new JLabel("Proceso:");
        lblProceso.setBounds(50, 110, 120, 25);
        add(lblProceso);

        JLabel lblDescripcion = new JLabel("Descripción:");
        lblDescripcion.setBounds(50, 150, 120, 25);
        add(lblDescripcion);

        JLabel lblFechaSalida = new JLabel("Fecha Salida:");
        lblFechaSalida.setBounds(50, 190, 120, 25);
        add(lblFechaSalida);

        // Text Fields and Combo Boxes
        txtReferencia = new JTextField(referencia);
        txtReferencia.setEditable(false);
        txtReferencia.setBounds(200, 30, 200, 25);
        add(txtReferencia);

        cmbEstado = new JComboBox<>(new String[]{"Pendiente", "Asignada", "Completada"});
        cmbEstado.setBounds(200, 70, 200, 25);
        add(cmbEstado);

        txtProceso = new JTextField();
        txtProceso.setBounds(200, 110, 200, 25);
        add(txtProceso);

        txtDescripcion = new JTextField();
        txtDescripcion.setBounds(200, 150, 200, 25);
        add(txtDescripcion);

        txtFechaSalida = new JTextField();
        txtFechaSalida.setBounds(200, 190, 200, 25);
        add(txtFechaSalida);

        // Buttons
        JButton btnModificar = new JButton("Modificar");
        btnModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String estado = (String) cmbEstado.getSelectedItem();
                String proceso = txtProceso.getText();
                String descripcion = txtDescripcion.getText();
                String fechaSalida = txtFechaSalida.getText();

                if (conexion.modificarOrden(referencia, estado, proceso, descripcion, fechaSalida)) {
                    JOptionPane.showMessageDialog(null, "Orden modificada exitosamente.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al modificar la orden.");
                }
            }
        });
        btnModificar.setBounds(250, 300, 100, 25);
        add(btnModificar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        btnCancelar.setBounds(100, 300, 100, 25);
        add(btnCancelar);
    }
}