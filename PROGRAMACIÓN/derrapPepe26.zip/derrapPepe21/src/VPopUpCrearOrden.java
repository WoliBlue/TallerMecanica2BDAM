import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VPopUpCrearOrden extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField txtReferencia;
    private JComboBox<String> cmbVehiculoMatricula;
    private JComboBox<String> cmbClienteDNI;
    private JComboBox<String> cmbServicioNombre;
    private JTextField txtDescripcion;
    private JTextField txtFechaPropuesta;
    private ConexionBD conexion;

    public VPopUpCrearOrden(ConexionBD conexion) {
        this.conexion = conexion;
        initialize();
    }

    private void initialize() {
        setTitle("DERRAP - Crear Orden");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 400);
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(243, 141, 52));
        setLayout(null);

        // Labels
        JLabel lblReferencia = new JLabel("Referencia:");
        lblReferencia.setBounds(50, 30, 120, 25);
        add(lblReferencia);

        JLabel lblVehiculo = new JLabel("Vehículo Matrícula:");
        lblVehiculo.setBounds(50, 70, 120, 25);
        add(lblVehiculo);

        JLabel lblCliente = new JLabel("Cliente DNI:");
        lblCliente.setBounds(50, 110, 120, 25);
        add(lblCliente);

        JLabel lblServicio = new JLabel("Servicio:");
        lblServicio.setBounds(50, 150, 120, 25);
        add(lblServicio);

        JLabel lblDescripcion = new JLabel("Descripción:");
        lblDescripcion.setBounds(50, 190, 120, 25);
        add(lblDescripcion);

        JLabel lblFechaPropuesta = new JLabel("Fecha Propuesta:");
        lblFechaPropuesta.setBounds(50, 230, 120, 25);
        add(lblFechaPropuesta);

        // Text Fields and Combo Boxes
        txtReferencia = new JTextField();
        txtReferencia.setBounds(200, 30, 200, 25);
        add(txtReferencia);

        cmbVehiculoMatricula = new JComboBox<>(conexion.cargarVehiculosMatriculas().toArray(new String[0]));
        cmbVehiculoMatricula.setBounds(200, 70, 200, 25);
        add(cmbVehiculoMatricula);

        cmbClienteDNI = new JComboBox<>(conexion.cargarClientesDNIs().toArray(new String[0]));
        cmbClienteDNI.setBounds(200, 110, 200, 25);
        add(cmbClienteDNI);

        cmbServicioNombre = new JComboBox<>(conexion.cargarServiciosNombres().toArray(new String[0]));
        cmbServicioNombre.setBounds(200, 150, 200, 25);
        add(cmbServicioNombre);
        
        txtDescripcion = new JTextField();
        txtDescripcion.setBounds(200, 190, 200, 25);
        add(txtDescripcion);

        txtFechaPropuesta = new JTextField();
        txtFechaPropuesta.setBounds(200, 230, 200, 25);
        add(txtFechaPropuesta);

        // Buttons
        JButton btnCrear = new JButton("Crear");
        btnCrear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String referencia = txtReferencia.getText();
                String vehiculoMatricula = (String) cmbVehiculoMatricula.getSelectedItem();
                String clienteDNI = (String) cmbClienteDNI.getSelectedItem();
                String servicioNombre = (String) cmbServicioNombre.getSelectedItem();
                String descripcion = txtDescripcion.getText();
                String fechaPropuesta = txtFechaPropuesta.getText();

                if (conexion.crearOrden(referencia, "Pendiente", "Sin proceso", fechaPropuesta, null, servicioNombre,
                        vehiculoMatricula, descripcion)) {
                    JOptionPane.showMessageDialog(null, "Orden creada exitosamente.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al crear la orden.");
                }
            }
        });
        btnCrear.setBounds(250, 300, 100, 25);
        add(btnCrear);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        btnCancelar.setBounds(100, 300, 100, 25);
        add(btnCancelar);
    }
}
