import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VPopUpAsignarVehiculo extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtMatricula;
    private ConexionBD conexion;
    private String clienteDNI;

    public VPopUpAsignarVehiculo(ConexionBD conexion, String clienteDNI) {
        this.conexion = conexion;
        this.clienteDNI = clienteDNI;
        initialize();
    }

    private void initialize() {
        setTitle("DERRAP - Asignar Vehículo");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(450, 200);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblMatricula = new JLabel("Matrícula:");
        lblMatricula.setBounds(50, 30, 120, 25);
        contentPane.add(lblMatricula);

        txtMatricula = new JTextField();
        txtMatricula.setBounds(180, 30, 200, 25);
        contentPane.add(txtMatricula);

        JButton btnAsignar = new JButton("Asignar");
        btnAsignar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String matricula = txtMatricula.getText();
                boolean asignado = conexion.asignarVehiculo(matricula, clienteDNI);
                if (asignado) {
                    JOptionPane.showMessageDialog(null, "Vehículo asignado correctamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "Error al asignar el vehículo.");
                }
                dispose();
            }
        });
        btnAsignar.setBounds(250, 80, 120, 25);
        contentPane.add(btnAsignar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        btnCancelar.setBounds(100, 80, 100, 25);
        contentPane.add(btnCancelar);
    }
}